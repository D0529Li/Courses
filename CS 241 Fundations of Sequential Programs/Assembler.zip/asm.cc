#include <iostream>
#include <string>
#include <vector>
#include <climits>
#include <unordered_map>
#include <algorithm>
#include "scanner.h"

using namespace std;

void displayBinary(vector<long long> res) {
	// This method should be invoked only during debugging.
	for (long long a : res) {
		vector<int> r;
		while (a) {
			r.push_back(a % 2);
			a /= 2;
		}
		int i = 0;
		reverse(r.begin(), r.end());
		for (int j = r.size(); j < 32; j++)
		{
			cout << "0";
			if (++i % 4 == 0) cout << " ";
		}
		for (int a : r) {
			cout << a;
			if (++i % 4 == 0) cout << " ";
		}
		cout << endl;
	}
}

void displayHex(vector<long long> res) {
	// This method should be invoked only during debugging.
	for (long long a : res) {
		vector<int> r;
		int i = 1;
		int curr = 0;
		while (a) {
			curr = curr + (a % 2) * i;
			i *= 2;
			a /= 2;
			if (i == 16) {
				r.push_back(curr);
				i = 1;
				curr = 0;
			}
		}
		if (curr != 0) r.push_back(curr);
		reverse(r.begin(), r.end());
		i = 0;
		for (int j = r.size(); j < 8; j++)
		{
			cout << "0";
			if (++i % 4 == 0) cout << " ";
		}
		for (int a : r) {
			if (a < 10) cout << a;
			else cout << char(a - 10 + 'a');
			if (++i % 4 == 0) cout << " ";
		}
		cout << endl;
	}
}

void displayMC(vector<long long> res)
{
	for (long long instr : res)
	{
		cout << char(instr >> 24) << char(instr >> 16) << char(instr >> 8) << char(instr);
	}
}

class symbols
{
public:
	symbols() {}

	void addSymbol(string s, int pos)
	{
		if (s[s.length() - 1] == ':')
			s = s.substr(0, s.length() - 1);
		if (table.find(s) == table.end())
			table[s] = pos;
		else
		{
			throw ScanningFailure("ERROR: Duplicated labels found. Label name: " + s);
		}
	}

	void displaySymbolTable()
	{
		for (pair<string, int> pair : table)
		{
			cerr << pair.first << " " << pair.second << endl;
		}
	}

	bool checkLabel(string s)
	{
		return table.find(s) != table.end();
	}

	int accessLabel(string s)
	{
		if (checkLabel(s))
			return table[s];
		else
			return -1;
	}

private:
	unordered_map<string, int> table;
};

int main()
{
	string line;
	vector<vector<Token>> inputs; // stores the input lines
	int pc = 0;
	bool operated = false; // checks whether there is a valid command in a line; reset when scanning a new line
	vector<long long> res;
	symbols symbolTable;
	try // First scan, which scans for all symbols and checks syntax.
	{
		while (getline(cin, line))
		{
			vector<Token> tokenLine = scan(line);
			inputs.push_back(tokenLine);
			for (int i = 0; i < tokenLine.size(); i++)
			{
				Token token = tokenLine[i];
				if (token.getKind() == Token::Kind::LABEL) // label
				{
					symbolTable.addSymbol(token.getLexeme(), pc);
				}
				else if (token.getKind() == Token::Kind::WORD) // .word
				{
					if (i < tokenLine.size() - 1) // .word...
					{
						Token nextToken = tokenLine[++i];
						if (nextToken.getKind() == Token::Kind::INT || nextToken.getKind() == Token::Kind::HEXINT) // .word 1234
						{
							long long val = nextToken.toLong();
							if (nextToken.getKind() == Token::Kind::INT)
							{
								if (val >= ((long long)1 << 32) || val < INT_MIN)
								{
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The decimal value is not within the range [-2147483648, 4294967295].");
								}
							}
							else
							{
								if (val > 0xffffffff || val < 0)
								{
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The hex value is not within the range [0, 0xffffffff].");
								}
							}
							if (i == tokenLine.size() - 1)
								operated = true;
							else
								throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too many arguments in the line.");
						}
						else if (nextToken.getKind() == Token::Kind::ID) // .word LABEL
						{
							if (i == tokenLine.size() - 1)
								operated = true;
							else
								throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too many arguments in the line.");
						}
						else
						{
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The next instruction after '.word' is not a number or a label.");
						}
					}
					else
					{
						throw ScanningFailure("ERROR(pc = " + to_string(pc) + ") : No following instruction after '.word'.");
					}
				}
				else if (token.getKind() == Token::Kind::ID) // Instruction
				{
					if (token.getLexeme() == "jr" || token.getLexeme() == "jalr")
					{
						if (i < tokenLine.size() - 1)
						{
							Token nextToken = tokenLine[++i];
							if (nextToken.getKind() == Token::Kind::REG)
							{
								int regNum = nextToken.toLong();
								if (regNum >= 0 && regNum <= 31)
								{
									if (i == tokenLine.size() - 1)
										operated = true;
									else
										throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too many arguments in a line.");
								}
								else
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The register number is not an integer within the range 0-31.");
							}
							else
								throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The next token after '" + token.getLexeme() + "' is not a register.");
						}
						else
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): No following token after '" + token.getLexeme() + "'");
					}
					else if (token.getLexeme() == "add" || token.getLexeme() == "sub" || token.getLexeme() == "slt" || token.getLexeme() == "sltu")
					{
						int j;
						for (j = 1; j <= 5; j++)
						{
							if (j % 2) // expect a register
							{
								if (i + j > tokenLine.size() - 1)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line. ");
								Token nextToken = tokenLine[i + j];
								if (nextToken.getKind() != Token::Kind::REG)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): At least one of the following arguments after '" + token.getLexeme() + "' is not a register.");
								int regVal = nextToken.toLong();
								if (regVal > 31 || regVal < 0)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The register number is not an integer within the range 0-31.");
							}
							else // expect a comma
							{
								if (i + j > tokenLine.size() - 1)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line. ");
								Token nextToken = tokenLine[i + j];
								if (nextToken.getKind() != Token::Kind::COMMA)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): At least one comma is missing.");
							}
						}
						if (i + j < tokenLine.size() - 1)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too many arguments in the line. ");
						operated = true;
					}
					else if (token.getLexeme() == "beq" || token.getLexeme() == "bne") {
						int j;
						for (j = 1; j <= 4; j++)
						{
							if (j % 2) // expect a register
							{
								if (i + j > tokenLine.size() - 1)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line. ");
								Token nextToken = tokenLine[i + j];
								if (nextToken.getKind() != Token::Kind::REG)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): At least one of the following two arguments after '" + token.getLexeme() + "' is not a register.");
								int regVal = nextToken.toLong();
								if (regVal > 31 || regVal < 0)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The register number is not an integer within the range 0-31.");
							}
							else // expect a comma
							{
								if (i + j > tokenLine.size() - 1)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line. ");
								Token nextToken = tokenLine[i + j];
								if (nextToken.getKind() != Token::Kind::COMMA)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): At least one comma is missing.");
							}
						}
						if (i + j > tokenLine.size() - 1)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line. ");
						Token nextToken = tokenLine[i + j];
						// expect a label or a number
						if (nextToken.getKind() == Token::Kind::INT || nextToken.getKind() == Token::Kind::HEXINT) {
							long long val = nextToken.toLong();
							if (nextToken.getKind() == Token::Kind::INT)
							{
								if (val >= (1 << 15) || val < (1 << 15) * (-1))
								{
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The decimal value is not within the range [-32768, 32767].");
								}
							}
							else
							{
								if (val > 0xffff || val < 0)
								{
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The hex value is not within the range [0, 65535].");
								}
							}
						}
						else if (nextToken.getKind() != Token::Kind::ID) {
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The last arguments after '" + token.getLexeme() + "' is not a label or a number.");
						}
						if (i + j < tokenLine.size() - 1)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too many arguments in the line. ");
						operated = true;
					}
					else if (token.getLexeme() == "lis" || token.getLexeme() == "mflo" || token.getLexeme() == "mfhi")
					{
						if (i == tokenLine.size() - 1) throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line.");
						Token nextToken = tokenLine[++i];
						if (nextToken.getKind() != Token::Kind::REG)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The following argument after '" + token.getLexeme() + "' is not a register.");
						int regVal = nextToken.toLong();
						if (regVal > 31 || regVal < 0)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The register number is not an integer within the range 0-31.");
						if (i != tokenLine.size() - 1) throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too many arguments in the line.");
						operated = true;
					}
					else if (token.getLexeme() == "mult" || token.getLexeme() == "multu" || token.getLexeme() == "div" || token.getLexeme() == "divu") {
						int j;
						for (j = 1; j <= 3; j++)
						{
							if (j % 2 == 1) // expect a register
							{
								if (i + j > tokenLine.size() - 1)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line. ");
								Token nextToken = tokenLine[i + j];
								if (nextToken.getKind() != Token::Kind::REG)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): At least one register is missing.");
								int regVal = nextToken.toLong();
								if (regVal > 31 || regVal < 0)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The register number is not an integer within the range 0-31.");
							}
							else // expect a comma
							{
								if (i + j > tokenLine.size() - 1)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line. ");
								Token nextToken = tokenLine[i + j];
								if (nextToken.getKind() != Token::Kind::COMMA)
									throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The comma is missing.");
							}
						}
						if (i + j < tokenLine.size())
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too many arguments in the line. ");
						operated = true;
					}
					else if (token.getLexeme() == "lw" || token.getLexeme() == "sw") {
						if (i > tokenLine.size() - 6)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too few arguments in the line. ");

						Token nextToken = tokenLine[i + 1];
						if (nextToken.getKind() != Token::Kind::REG)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): At least one of the following arguments after '" + token.getLexeme() + "' is not a register.");
						int regVal = nextToken.toLong();
						if (regVal > 31 || regVal < 0)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The register number is not an integer within the range 0-31.");

						nextToken = tokenLine[i + 2];
						if (nextToken.getKind() != Token::Kind::COMMA)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The comma is missing.");

						nextToken = tokenLine[i + 3];
						if (nextToken.getKind() == Token::Kind::INT) {
							int val = nextToken.toLong();
							if (val >= (1 << 15) || val < (1 << 15) * (-1))
								throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The decimal offset is not within the range [-32768, 32767].");
						}
						else if (nextToken.getKind() == Token::Kind::HEXINT) {
							int val = nextToken.toLong();
							if (val < 0 || val > 0xffff)
								throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The hex offset is not within the range [0, 0xffff].");
						}
						else throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The offset number is missing.");

						nextToken = tokenLine[i + 4];
						if (nextToken.getKind() != Token::Kind::LPAREN)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The left parenthesis is missing.");

						nextToken = tokenLine[i + 5];
						if (nextToken.getKind() != Token::Kind::REG)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): At least one of the following arguments after '" + token.getLexeme() + "' is not a register.");
						regVal = nextToken.toLong();
						if (regVal > 31 || regVal < 0)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The register number is not an integer within the range 0-31.");

						nextToken = tokenLine[i + 6];
						if (nextToken.getKind() != Token::Kind::RPAREN)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The right parenthesis is missing.");

						if (i + 6 < tokenLine.size() - 1)
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): There are too many arguments in the line. ");
						operated = true;
					}
					else throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): Illegal instruction name found.");
				}
				if (operated)
				{
					pc += 4;
					operated = false;
					break;
				}
			}
		}
	}
	catch (ScanningFailure& f)
	{
		cerr << f.what() << endl;
		return 1;
	}

	pc = 0;
	operated = false;

	try // Second scan
	{
		for (vector<Token> tokenLine : inputs)
		{
			long long currCode = 0;
			for (int i = 0; i < tokenLine.size(); i++)
			{
				Token token = tokenLine[i];
				if (token.getKind() == Token::Kind::LABEL) // label. should do nothing.
				{
					;
				}
				else if (token.getKind() == Token::Kind::WORD) // .word
				{
					Token nextToken = tokenLine[++i];
					if (nextToken.getKind() == Token::Kind::INT || nextToken.getKind() == Token::Kind::HEXINT) // .word 1234
					{
						long long val = nextToken.toLong();
						currCode |= val;
					}
					else if (nextToken.getKind() == Token::Kind::ID) // .word LABEL
					{
						// check whether the label is valid
						if (!symbolTable.checkLabel(nextToken.getLexeme()))
							throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): Undefined label detected.");
						else
							res.push_back(symbolTable.accessLabel(nextToken.getLexeme()));
					}
				}
				else if (token.getKind() == Token::Kind::ID) // instruction
				{
					if (token.getLexeme() == "jr" || token.getLexeme() == "jalr")
					{
						Token nextToken = tokenLine[++i];
						currCode |= (1 << 3);
						if (token.getLexeme() == "jalr")
							currCode |= 1;
						currCode |= (nextToken.toLong() << 21);
					}
					else if (token.getLexeme() == "add" || token.getLexeme() == "sub" || token.getLexeme() == "slt" || token.getLexeme() == "sltu")
					{
						if (token.getLexeme() == "add")
							currCode |= (1 << 5);
						else if (token.getLexeme() == "sub")
							currCode |= 34;
						else if (token.getLexeme() == "slt")
							currCode |= 42;
						else if (token.getLexeme() == "sltu")
							currCode |= 43;
						Token nextToken = tokenLine[++i];
						currCode |= (nextToken.toLong() << 11);
						i += 2;
						nextToken = tokenLine[i];
						currCode |= (nextToken.toLong() << 21);
						i += 2;
						nextToken = tokenLine[i];
						currCode |= (nextToken.toLong() << 16);
					}
					else if (token.getLexeme() == "beq" || token.getLexeme() == "bne")
					{
						currCode |= (1 << 28);
						if (token.getLexeme() == "bne") currCode |= (1 << 26);
						Token nextToken = tokenLine[++i];
						currCode |= (nextToken.toLong() << 21);
						i += 2;
						nextToken = tokenLine[i];
						currCode |= (nextToken.toLong() << 16);
						i += 2;
						nextToken = tokenLine[i];
						if (nextToken.getKind() == Token::Kind::ID) {
							string label = nextToken.getLexeme();
							if (!symbolTable.checkLabel(label))
								throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): Undefined label name found.");
							long long val = (symbolTable.accessLabel(label) - pc - 4) / 4;
							if (val >= (1 << 15) || val < (1 << 15) * (-1))
							{
								throw ScanningFailure("ERROR (pc = " + to_string(pc) + "): The value is not within the range [-32768, 32767]; the program might be too long to execute.");
							}
							currCode |= (unsigned short)val;
						}
						else {
							currCode |= (unsigned short)(nextToken.toLong());
						}
					}
					else if (token.getLexeme() == "lis" || token.getLexeme() == "mflo" || token.getLexeme() == "mfhi")
					{
						currCode |= (1 << 4);
						if (token.getLexeme() == "lis") currCode |= (1 << 2);
						else if (token.getLexeme() == "mflo") currCode |= (1 << 1);
						long long regVal = tokenLine[++i].toLong();
						currCode |= (regVal << 11);
					}
					else if (token.getLexeme() == "mult" || token.getLexeme() == "multu" || token.getLexeme() == "div" || token.getLexeme() == "divu") {
						currCode |= (1 << 4);
						if (token.getLexeme() == "mult")
							currCode |= 8;
						else if (token.getLexeme() == "multu")
							currCode |= 9;
						else if (token.getLexeme() == "div")
							currCode |= 10;
						else if (token.getLexeme() == "divu")
							currCode |= 11;
						Token nextToken = tokenLine[++i];
						currCode |= (nextToken.toLong() << 21);
						i += 2;
						nextToken = tokenLine[i];
						currCode |= (nextToken.toLong() << 16);
					}
					else if (token.getLexeme() == "lw" || token.getLexeme() == "sw") {
						currCode |= ((long long)1 << 31);
						currCode |= (1 << 26);
						currCode |= (1 << 27);
						if (token.getLexeme() == "sw") currCode |= (1 << 29);
						Token nextToken = tokenLine[i + 1];
						currCode |= (nextToken.toLong() << 16);
						nextToken = tokenLine[i + 3];
						currCode |= (unsigned short)(nextToken.toLong());
						nextToken = tokenLine[i + 5];
						currCode |= (nextToken.toLong() << 21);
					}
					operated = true;
				}
				if (operated)
				{
					pc += 4;
					res.push_back(currCode);
					operated = false;
					break;
				}
			}
		}
	}
	catch (ScanningFailure& f)
	{
		cerr << f.what() << endl;
		return 1;
	}
	//displayHex(res);
	//displayBinary(res);
	displayMC(res);
	return 0;
}